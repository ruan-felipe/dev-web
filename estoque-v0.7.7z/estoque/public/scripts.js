// Função para alternar a visibilidade do modal do fornecedor
function adicionarFornecedores() {
    const modal = document.getElementById('modalFornecedor');
    modal.classList.toggle('hide'); // Alterna a classe 'hide'
}

// Função para alternar a visibilidade do modal de estoque
function adicionarEstoque() {
    const modal = document.getElementById('modalEstoque');
    modal.classList.toggle('hide'); // Alterna a classe 'hide'
}

// Função para fechar o modal quando o botão de voltar é clicado
function closeModal() {
    const modalFornecedor = document.getElementById('modalFornecedor');
    const modalEstoque = document.getElementById('modalEstoque');

    modalFornecedor.classList.add('hide');
    modalEstoque.classList.add('hide');
}

// Função para buscar produtos do servidor e exibi-los na tabela de estoque
async function fetchProdutos() {
    try {
        const response = await fetch('/produtos');
        const produtos = await response.json();
        const tableBody = document.querySelector('#produtosTable tbody');

        // Limpa a tabela antes de adicionar novos dados
        tableBody.innerHTML = '';

        produtos.forEach(produto => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${produto.codigo}</td>
                <td>${produto.descricao}</td>
                <td>${produto.categoria}</td>
                <td>${produto.quantidade}</td>
                <td>${produto.unidade}</td>
                <td>${produto.preco}</td>
                <td>${produto.fornecedor}</td>
                <td>${produto.data_entrada}</td>
                <td>${produto.data_validade}</td>
                <td>${produto.localizacao}</td>
            `;
            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
    }
}

// Função para buscar fornecedores do servidor e exibi-los na tabela de fornecedores
async function fetchFornecedores() {
    try {
        const response = await fetch('/fornecedores');
        const fornecedores = await response.json();
        const tableBody = document.querySelector('#fornecedoresTable tbody');

        // Limpa a tabela antes de adicionar novos dados
        tableBody.innerHTML = '';

        fornecedores.forEach(fornecedor => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${fornecedor.id}</td>
                <td>${fornecedor.nome}</td>
                <td>${fornecedor.cnpj_cpf}</td>
                <td>${fornecedor.telefone}</td>
                <td>${fornecedor.email}</td>
                <td>${fornecedor.site}</td>
                <td>${fornecedor.avaliacao}</td>
                <td>${fornecedor.descontos}</td>
            `;
            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Erro ao buscar fornecedores:', error);
    }
}

// Chama a função para buscar produtos ao carregar a página de estoque
if (window.location.pathname === '/estoque.html') {
    window.onload = fetchProdutos;
}

// Chama a função para buscar fornecedores ao carregar a página de fornecedores
if (window.location.pathname === '/fornecedor.html') {
    window.onload = fetchFornecedores;
}
