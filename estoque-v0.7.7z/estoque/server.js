// server.js
const express = require('express');
const app = express();
const db = require('./db'); // Importa a conexão com o banco de dados
const path = require('path');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public')); // Serve arquivos estáticos da pasta public

// Endpoint para obter todos os produtos
app.get('/produtos', (req, res) => {
    db.all(`SELECT * FROM produtos`, [], (err, rows) => {
        if (err) {
            console.error('Erro ao obter produtos:', err.message);
            res.status(500).send('Erro ao obter produtos.');
        } else {
            res.json(rows);
        }
    });
});

// Endpoint para obter todos os fornecedores
app.get('/fornecedores', (req, res) => {
    db.all(`SELECT * FROM fornecedores`, [], (err, rows) => {
        if (err) {
            console.error('Erro ao obter fornecedores:', err.message);
            res.status(500).send('Erro ao obter fornecedores.');
        } else {
            res.json(rows);
        }
    });
});

// Endpoint para adicionar fornecedor
app.post('/fornecedor', (req, res) => {
    const { nomeFornecedor, docIdentificacao, telefone, email, site, avaliacao, descontos } = req.body;
    
    // Lógica para inserir fornecedor no banco de dados
    db.run(`INSERT INTO fornecedores (nome, cnpj_cpf, telefone, email, site, avaliacao, descontos) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [nomeFornecedor, docIdentificacao, telefone, email, site, avaliacao, descontos],
        function (err) {
            if (err) {
                console.error('Erro ao adicionar fornecedor:', err.message);
                return res.status(500).send('Erro ao adicionar fornecedor.');
            }
            res.redirect('/fornecedor.html'); // Redireciona após adicionar
        }
    );
});

// Endpoint para adicionar produto
app.post('/estoque', (req, res) => {
    const { codigoProduto, descricaoProduto, categoria, quantidade, unidadeMedida, precoCompra, fornecedor, dataEntrada, dataValidade, localizacao } = req.body;

    // Lógica para inserir produto no banco de dados
    db.run(`INSERT INTO produtos (codigo, descricao, categoria, quantidade, unidade, preco, fornecedor, data_entrada, data_validade, localizacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [codigoProduto, descricaoProduto, categoria, quantidade, unidadeMedida, precoCompra, fornecedor, dataEntrada, dataValidade, localizacao],
        function (err) {
            if (err) {
                console.error('Erro ao adicionar produto:', err.message);
                return res.status(500).send('Erro ao adicionar produto.');
            }
            res.redirect('/estoque.html'); // Redireciona após adicionar
        }
    );
});





// Rota para a página inicial
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Rota para a página de estoque
app.get('/estoque.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'estoque.html'));
});

// Rota para a página de fornecedores
app.get('/fornecedor.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'fornecedor.html'));
});

// Inicia o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
